package com.aliendroid.fakecall;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.applovin.adview.AppLovinInterstitialAd;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinSdk;
import com.aliendroid.fakecall.config.Pengaturan;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.StartAppAd;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.aliendroid.fakecall.adapter.FakeAdapter.gambar;
import static com.aliendroid.fakecall.adapter.FakeAdapter.judul;
import static com.aliendroid.fakecall.adapter.FakeAdapter.video;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK1;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK2;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK3;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK4;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK5;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_INTER;
import static com.aliendroid.fakecall.config.Pengaturan.PENGATURAN_IKLAN;

public class FBVideoCallActivity extends AppCompatActivity implements SurfaceHolder.Callback{
    CircleImageView gambrH;
    ImageView gambrB, imgback;
    MediaPlayer mp;
    RelativeLayout terima, tolak, tolak2, atas2;
    LinearLayout atas, bawah;
    int Seconds, Minutes, MilliSeconds, hours ;
    long MillisecondTime, StartTime, TimeBuff, UpdateTime = 0L ;
    Handler handler;
    TextView calling;
    Camera camera;
    SurfaceView surfaceView ;
    SurfaceHolder surfaceHolder;
    VideoView videoView;

    private com.google.android.gms.ads.InterstitialAd mInterstitialAd;
    private com.facebook.ads.InterstitialAd interstitialAdfb;
    private AppLovinInterstitialAdDialog interstitialAdlovin;
    private AppLovinAd loadedAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_f_b_video_call);


        interstitialAdfb = new com.facebook.ads.InterstitialAd(this,  Pengaturan.FAN_INTER);
        interstitialAdfb.loadAd();


        mInterstitialAd = new com.google.android.gms.ads.InterstitialAd(FBVideoCallActivity.this);
        mInterstitialAd.setAdUnitId(ADMOB_INTER);
        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());


        AppLovinSdk.getInstance( this ).getAdService().loadNextAd( AppLovinAdSize.INTERSTITIAL, new AppLovinAdLoadListener()
        {
            @Override
            public void adReceived(AppLovinAd ad)
            {
                loadedAd = ad;
            }

            @Override
            public void failedToReceiveAd(int errorCode)
            {
                // Look at AppLovinErrorCodes.java for list of error codes.
            }
        } );
        interstitialAdlovin = AppLovinInterstitialAd.create( AppLovinSdk.getInstance( this ), this );



        surfaceView = findViewById(R.id.surfaceView);
        surfaceView.setVisibility(View.GONE);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setFormat(PixelFormat.OPAQUE);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);
        videoView = findViewById(R.id.videoView);
        videoView.setMediaController(null);

        String uriPath = video;
        if (Pengaturan.ON_OFF_DATA.equals("1")){
            Uri uri = Uri.parse(uriPath);
            videoView.setVideoURI(uri);
            videoView.requestFocus();
        } else if (Pengaturan.ON_OFF_DATA.equals("0")){
            String fileName = "android.resource://"+  BuildConfig.APPLICATION_ID + "/raw/"+video;
            videoView.setVideoURI(Uri.parse(fileName));
            videoView.requestFocus();
        }

        handler = new Handler() ;
        atas = findViewById(R.id.layutama);
        bawah = findViewById(R.id.laybawah2);
        calling = findViewById(R.id.txtwaktu);

        mp = MediaPlayer.create(this, R.raw.facebook);
        mp.start();
        mp.setLooping(true);

        tolak = findViewById(R.id.laytolak);
        tolak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FBVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                if (PENGATURAN_IKLAN.equals("1")){

                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
                    } else {
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

                    }
                } else if (PENGATURAN_IKLAN.equals("3")){
                    interstitialAdlovin.showAndRender( loadedAd );
                } else if(PENGATURAN_IKLAN.equals("2")) {
                    if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                        interstitialAdfb.loadAd();
                    } else {
                        interstitialAdfb.show();

                    }
                } else if (PENGATURAN_IKLAN.equals("4")){
                    StartAppAd.showAd(FBVideoCallActivity.this);
                }

            }
        });

        imgback = findViewById(R.id.imgback2);
        imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FBVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                if (PENGATURAN_IKLAN.equals("1")){

                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
                    } else {
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

                    }
                } else if (PENGATURAN_IKLAN.equals("3")){
                    interstitialAdlovin.showAndRender( loadedAd );
                } else if(PENGATURAN_IKLAN.equals("2")) {
                    if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                        interstitialAdfb.loadAd();
                    } else {
                        interstitialAdfb.show();

                    }
                } else if (PENGATURAN_IKLAN.equals("4")){
                    StartAppAd.showAd(FBVideoCallActivity.this);
                }
            }
        });

        tolak2 = findViewById(R.id.laytolak2);
        tolak2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FBVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                if (PENGATURAN_IKLAN.equals("1")){

                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
                    } else {
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

                    }
                } else if (PENGATURAN_IKLAN.equals("3")){
                    interstitialAdlovin.showAndRender( loadedAd );
                } else if(PENGATURAN_IKLAN.equals("2")) {
                    if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                        interstitialAdfb.loadAd();
                    } else {
                        interstitialAdfb.show();

                    }
                } else if (PENGATURAN_IKLAN.equals("4")){
                    StartAppAd.showAd(FBVideoCallActivity.this);
                }

            }
        });

        terima = findViewById(R.id.layterima);
        terima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                surfaceView.setVisibility(View.VISIBLE);
                atas.setVisibility(View.GONE);
                bawah.setVisibility(View.VISIBLE);
                gambrB.setVisibility(View.GONE);
                videoView.start();


            }
        });


        TextView judulH = findViewById(R.id.txtfbname);
        judulH.setText(judul);

        gambrH = findViewById(R.id.fbimguser);
        gambrB = findViewById(R.id.imgback);

        Picasso.get()
                .load(gambar)
                .into(gambrH);
        Picasso.get()
                .load(gambar)
                .into(gambrB);
    }


    public Runnable runnable = new Runnable() {

        @SuppressLint({"DefaultLocale", "SetTextI18n"})
        public void run() {

            MillisecondTime = SystemClock.uptimeMillis() - StartTime;

            UpdateTime = TimeBuff + MillisecondTime;

            Seconds = (int) (UpdateTime / 1000);

            Minutes = Seconds / 60;

            Seconds = Seconds % 60;
            hours = Minutes/60;

            MilliSeconds = (int) (UpdateTime % 1000);

            calling.setText(String.format("%02d", hours) +":"+ String.format("%02d", Minutes) + ":"
                    + String.format("%02d", Seconds));

            handler.postDelayed(this, 0);
        }

    };

    public void onBackPressed(){
        mp.stop();
        Intent intent = new Intent(FBVideoCallActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        if (PENGATURAN_IKLAN.equals("1")){

            if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
                mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                        .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                        .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
            } else {
                mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                        .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                        .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

            }
        } else if (PENGATURAN_IKLAN.equals("3")){
            interstitialAdlovin.showAndRender( loadedAd );
        } else if(PENGATURAN_IKLAN.equals("2")) {
            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                interstitialAdfb.loadAd();
            } else {
                interstitialAdfb.show();

            }
        } else if (PENGATURAN_IKLAN.equals("4")){
            StartAppAd.showAd(FBVideoCallActivity.this);
        }
    }

    public void surfaceCreated(SurfaceHolder surfaceHolder ) {

        camera = Camera.open(1);
        Camera.Parameters parameters;
        parameters = camera.getParameters();
        camera.setParameters(parameters);
        camera.setDisplayOrientation(90);
        try {
            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();


        }catch (Exception e){
        }

    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        camera.stopPreview();
        camera.release();
        camera=null;

    }

}