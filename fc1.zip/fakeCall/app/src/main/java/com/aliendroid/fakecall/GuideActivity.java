package com.aliendroid.fakecall;

import android.os.Bundle;
import android.webkit.WebView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.aliendroid.fakecall.config.Pengaturan;


public class GuideActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);
        TextView txtjudul = findViewById(R.id.txtjudul);
        txtjudul.setText("How to use");

        WebView webView = (WebView) findViewById(R.id.webview);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(Pengaturan.Guide_app);
    }
    @Override
    public void onBackPressed()
    {
        finish();
    }

}