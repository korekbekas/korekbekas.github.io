package com.aliendroid.fakecall;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.applovin.adview.AppLovinAdView;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.aliendroid.fakecall.config.Pengaturan;
import com.aliendroid.fakecall.util.AppReceiver;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.MediaViewListener;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.ads.banner.Mrec;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.aliendroid.fakecall.adapter.FakeAdapter.gambar;
import static com.aliendroid.fakecall.adapter.FakeAdapter.judul;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_NATIV;
import static com.aliendroid.fakecall.config.Pengaturan.FAN_NATIVE;
import static com.aliendroid.fakecall.config.Pengaturan.PENGATURAN_IKLAN;

public class DetailFakeActivity extends AppCompatActivity implements NativeAdListener {
    private int NOTIFICATION_ID = 1;
    private PendingIntent pendingIntent;
    private static final int ALARM_REQUEST_CODE = 134;
    private RadioGroup list_action, list_form, list_time;
    protected static final String TAG = DetailFakeActivity.class.getSimpleName();
    public static int rd_vid =1;
    public static int rd_form =1;
    public static int rd_time =1;
    public static String status_time="Wait for 2 seconds";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detai_fake_activity);

        TextView judulH = findViewById(R.id.txtjudul);
        final LinearLayout banner_programmatic_layout = findViewById(R.id.banner_programmatic_layout);
        final AppLovinAdView adView = findViewById( R.id.ad_view );
        adView.setAdLoadListener( new AppLovinAdLoadListener()
        {
            @Override
            public void adReceived(final AppLovinAd ad)
            {
                banner_programmatic_layout.setVisibility(View.VISIBLE);
            }

            @Override
            public void failedToReceiveAd(final int errorCode)
            {
                banner_programmatic_layout.setVisibility(View.GONE);

            }
        } );
        if (Pengaturan.PENGATURAN_IKLAN.equals("1")){
            iklannativeadmob();
            banner_programmatic_layout.setVisibility(View.GONE);
        }else if (Pengaturan.PENGATURAN_IKLAN.equals("2")){
            nativefan();
            banner_programmatic_layout.setVisibility(View.GONE);
        }else if (PENGATURAN_IKLAN.equals("3")){
            adView.loadNextAd();
        } else if (PENGATURAN_IKLAN.equals("4")){
            // Get the Main relative layout of the entire activity
            RelativeLayout mainLayout = (RelativeLayout)findViewById(R.id.mainLayout);

// Define StartApp Mrec
            Mrec startAppMrec = new Mrec(this);
            RelativeLayout.LayoutParams mrecParameters =
                    new RelativeLayout.LayoutParams(
                            RelativeLayout.LayoutParams.WRAP_CONTENT,
                            RelativeLayout.LayoutParams.WRAP_CONTENT);
            mrecParameters.addRule(RelativeLayout.CENTER_HORIZONTAL);

// Add to main Layout
            mainLayout.addView(startAppMrec, mrecParameters);
            banner_programmatic_layout.setVisibility(View.GONE);
        }

        list_action = findViewById(R.id.list_action);
        list_action.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id){
                    case R.id.rd_vid:
                        rd_vid = 1;

                        break;
                    case R.id.rd_voic:
                        rd_vid = 2;
                        break;

                }
            }
        });


        list_form = findViewById(R.id.lict_form);
        list_form.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id){
                    case R.id.rdwa:
                        rd_form = 1;
                        break;
                    case R.id.rdfb:
                        rd_form = 2;
                        break;
                    case R.id.rdduo:
                        rd_form = 3;
                        break;

                }
            }
        });

        list_time = findViewById(R.id.list_time);
        list_time.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id){
                    case R.id.rd1:
                        rd_time = 1;
                        status_time = "Wait for 2 seconds";
                        break;
                    case R.id.rd10:
                        rd_time = 10;
                        status_time = "Wait for 10 seconds";
                        break;
                    case R.id.rd30:
                        rd_time = 30;
                        status_time = "Wait for 30 seconds";
                        break;
                    case R.id.rd60:
                        rd_time = 60;
                        status_time = "Wait for 1 minutes";
                        break;
                    case R.id.rd300:
                        rd_time = 300;
                        status_time = "Wait for 5 minutes";
                        break;

                }
            }
        });

        judulH.setText(judul);

        CircleImageView gambrH = findViewById(R.id.imageheader);

        Picasso.get()
                .load(gambar)
                .into(gambrH);

        Intent alarmIntent = new Intent(this, AppReceiver.class);
        pendingIntent = PendingIntent.getBroadcast(this, ALARM_REQUEST_CODE, alarmIntent, 0);

        Button tbtutor = findViewById(R.id.tblstart);
        tbtutor.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                if (rd_time==1) {
                    if (rd_form == 1) {
                        if (rd_vid == 2) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, WAVoiceCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else if (rd_vid == 1) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, WAVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else {
                            Intent intent2 = new Intent(DetailFakeActivity.this, WAVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        }
                    } else if (rd_form == 2) {
                        if (rd_vid == 2) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, FBVoiceCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else if (rd_vid == 1) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, FBVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else {
                            Intent intent2 = new Intent(DetailFakeActivity.this, FBVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        }
                    }else if (rd_form == 3) {
                        if (rd_vid == 2) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, TeleVoiceCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else if (rd_vid == 1) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, TeleVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else {
                            Intent intent2 = new Intent(DetailFakeActivity.this, TeleVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        }
                    }
                } else {
                    Calendar cal = Calendar.getInstance();
                    cal.add(Calendar.SECOND, rd_time);
                    AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    //set alarm manager dengan memasukkan waktu yang telah dikonversi menjadi milliseconds
                    manager.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
                    Toast.makeText(DetailFakeActivity.this, status_time, Toast.LENGTH_SHORT).show();
                    finish();
                    MainActivity.fa.finish();

                }
                /*
                Intent intent = new Intent(DetaiFakeActivity.this, TeleVideoCallActivity.class);
                startActivity(intent);

                //set waktu sekarang berdasarkan interval
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.SECOND, rd_time);
                AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                //set alarm manager dengan memasukkan waktu yang telah dikonversi menjadi milliseconds
                manager.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
                Toast.makeText(DetaiFakeActivity.this, status_time, Toast.LENGTH_SHORT).show();
                finish();
                MainActivity.fa.finish();

                 */

            }
        });
    }
    private @Nullable
    TextView nativeAdStatus;
    private @Nullable
    LinearLayout adChoicesContainer;

    private @Nullable
    NativeAdLayout nativeAdLayout;
    private @Nullable
    NativeAd nativeAd;
    private @Nullable
    AdOptionsView adOptionsView;
    private MediaView nativeAdMedia;

    private int originalScreenOrientationFlag;


    private RelativeLayout iklannative;
    private void iklannativeadmob() {
        iklannative = findViewById(R.id.iklannative);
        AdLoader adLoader = new AdLoader.Builder(this,ADMOB_NATIV)
                .forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                    @Override
                    public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                        NativeTemplateStyle styles = new
                                NativeTemplateStyle.Builder().build();

                        TemplateView template = findViewById(R.id.my_template);
                        template.setStyles(styles);
                        template.setNativeAd(unifiedNativeAd);

                    }



                })

                .withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(int errorCode) {
                        iklannative.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdLoaded() {
                        iklannative.setVisibility(View.VISIBLE);
                    }

                })
                .withNativeAdOptions(new NativeAdOptions.Builder()
                        // Methods in the NativeAdOptions.Builder class can be
                        // used here to specify individual options settings.
                        .build())
                .build();

        adLoader.loadAd(new AdRequest.Builder().build());

    }

    @Override
    public void onBackPressed()
    {
       finish();
    }

    @Override
    protected void onDestroy() {
        if (nativeAdMedia != null) {
            nativeAdMedia.destroy();
        }

        if (nativeAd != null) {
            nativeAd.unregisterView();
            nativeAd.destroy();
        }
        super.onDestroy();

    }

    void nativefan(){
        nativeAdLayout = findViewById(R.id.native_ad_container);
        adChoicesContainer = findViewById(R.id.ad_choices_container);
        nativeAd = new NativeAd(this, FAN_NATIVE);
        nativeAd.loadAd(
                nativeAd.buildLoadAdConfig().withAdListener(DetailFakeActivity.this).build());

    }


    @Override
    public void onMediaDownloaded(Ad ad) {

    }

    @Override
    public void onError(Ad ad, AdError adError) {

    }

    @Override
    public void onAdLoaded(Ad ad) {
        if (nativeAd == null || nativeAd != ad) {
            // Race condition, load() called again before last ad was displayed
            return;
        }

        if (nativeAdLayout == null) {
            return;
        }

        // Unregister last ad
        nativeAd.unregisterView();

        if (nativeAdStatus != null) {
            nativeAdStatus.setText("");
        }

        if (!nativeAd.isAdLoaded() || nativeAd.isAdInvalidated()) {
            if (nativeAdStatus != null) {
                nativeAdStatus.setText("Ad is not loaded or invalidated.");
            }
            return;
        }

        if (adChoicesContainer != null) {
            adOptionsView = new AdOptionsView(DetailFakeActivity.this, nativeAd, nativeAdLayout);
            adChoicesContainer.removeAllViews();
            adChoicesContainer.addView(adOptionsView, 0);
        }

        inflateAd(nativeAd, nativeAdLayout);

        // Registering a touch listener to log which ad component receives the touch event.
        // We always return false from onTouch so that we don't swallow the touch event (which
        // would prevent click events from reaching the NativeAd control).
        // The touch listener could be used to do animations.
        nativeAd.setOnTouchListener(
                new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View view, MotionEvent event) {
                        if (event.getAction() == MotionEvent.ACTION_DOWN) {
                            int i = view.getId();
                            if (i == R.id.native_ad_call_to_action) {
                                Log.d(TAG, "Call to action button clicked");
                            } else if (i == R.id.native_ad_media) {
                                Log.d(TAG, "Main image clicked");
                            } else {
                                Log.d(TAG, "Other ad component clicked");
                            }
                        }
                        return false;
                    }
                });
    }

    @Override
    public void onAdClicked(Ad ad) {

    }

    @Override
    public void onLoggingImpression(Ad ad) {

    }

    private void inflateAd(NativeAd nativeAd, View adView) {
        Log.d(TAG, "Aspect ratio of ad: " + nativeAd.getAspectRatio());

        // Create native UI using the ad metadata.
        MediaView nativeAdIcon = adView.findViewById(R.id.native_ad_icon);
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        TextView nativeAdBody = adView.findViewById(R.id.native_ad_body);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        nativeAdMedia = adView.findViewById(R.id.native_ad_media);
        nativeAdMedia.setListener(getMediaViewListener());

        // Setting the Text
        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
        nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
        nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdTitle.setText(nativeAd.getAdvertiserName());
        nativeAdBody.setText(nativeAd.getAdBodyText());
        sponsoredLabel.setText(R.string.sponsored);

        // You can use the following to specify the clickable areas.
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdIcon);
        clickableViews.add(nativeAdMedia);
        clickableViews.add(nativeAdCallToAction);
        nativeAd.registerViewForInteraction(
                nativeAdLayout, nativeAdMedia, nativeAdIcon, clickableViews);

        // Optional: tag views
        NativeAdBase.NativeComponentTag.tagView(nativeAdIcon, NativeAdBase.NativeComponentTag.AD_ICON);
        NativeAdBase.NativeComponentTag.tagView(nativeAdTitle, NativeAdBase.NativeComponentTag.AD_TITLE);
        NativeAdBase.NativeComponentTag.tagView(nativeAdBody, NativeAdBase.NativeComponentTag.AD_BODY);
        NativeAdBase.NativeComponentTag.tagView(nativeAdSocialContext, NativeAdBase.NativeComponentTag.AD_SOCIAL_CONTEXT);
        NativeAdBase.NativeComponentTag.tagView(nativeAdCallToAction, NativeAdBase.NativeComponentTag.AD_CALL_TO_ACTION);
    }

    private static MediaViewListener getMediaViewListener() {
        return new MediaViewListener() {
            @Override
            public void onVolumeChange(MediaView mediaView, float volume) {
                Log.i(TAG, "MediaViewEvent: Volume " + volume);
            }

            @Override
            public void onPause(MediaView mediaView) {
                Log.i(TAG, "MediaViewEvent: Paused");
            }

            @Override
            public void onPlay(MediaView mediaView) {
                Log.i(TAG, "MediaViewEvent: Play");
            }

            @Override
            public void onFullscreenBackground(MediaView mediaView) {
                Log.i(TAG, "MediaViewEvent: FullscreenBackground");
            }

            @Override
            public void onFullscreenForeground(MediaView mediaView) {
                Log.i(TAG, "MediaViewEvent: FullscreenForeground");
            }

            @Override
            public void onExitFullscreen(MediaView mediaView) {
                Log.i(TAG, "MediaViewEvent: ExitFullscreen");
            }

            @Override
            public void onEnterFullscreen(MediaView mediaView) {
                Log.i(TAG, "MediaViewEvent: EnterFullscreen");
            }

            @Override
            public void onComplete(MediaView mediaView) {
                Log.i(TAG, "MediaViewEvent: Completed");
            }
        };
    }



}