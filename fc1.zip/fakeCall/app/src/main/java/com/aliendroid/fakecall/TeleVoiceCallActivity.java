package com.aliendroid.fakecall;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.aliendroid.fakecall.config.Pengaturan;
import com.applovin.adview.AppLovinInterstitialAd;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinSdk;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.StartAppAd;

import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.aliendroid.fakecall.adapter.FakeAdapter.gambar;
import static com.aliendroid.fakecall.adapter.FakeAdapter.judul;
import static com.aliendroid.fakecall.adapter.FakeAdapter.voice;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK1;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK2;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK3;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK4;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK5;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_INTER;
import static com.aliendroid.fakecall.config.Pengaturan.PENGATURAN_IKLAN;

public class TeleVoiceCallActivity extends AppCompatActivity {
    MediaPlayer mp;
    private RelativeLayout cancel, terima, pesan, tolak;
    private LinearLayout atas, bawah;
    int Seconds, Minutes, MilliSeconds, hours ;
    long MillisecondTime, StartTime, TimeBuff, UpdateTime = 0L ;
    Handler handler;
    private TextView calling, nameuser;
    private ImageView imguser,  imguser2, adduser;
    CircleImageView gambrH;

    private com.google.android.gms.ads.InterstitialAd mInterstitialAd;
    private com.facebook.ads.InterstitialAd interstitialAdfb;
    private AppLovinInterstitialAdDialog interstitialAdlovin;
    private AppLovinAd loadedAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tele_voice_call);



        interstitialAdfb = new com.facebook.ads.InterstitialAd(this,  Pengaturan.FAN_INTER);
        interstitialAdfb.loadAd();


        mInterstitialAd = new com.google.android.gms.ads.InterstitialAd(TeleVoiceCallActivity.this);
        mInterstitialAd.setAdUnitId(ADMOB_INTER);
        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());


        AppLovinSdk.getInstance( this ).getAdService().loadNextAd( AppLovinAdSize.INTERSTITIAL, new AppLovinAdLoadListener()
        {
            @Override
            public void adReceived(AppLovinAd ad)
            {
                loadedAd = ad;
            }

            @Override
            public void failedToReceiveAd(int errorCode)
            {
                // Look at AppLovinErrorCodes.java for list of error codes.
            }
        } );
        interstitialAdlovin = AppLovinInterstitialAd.create( AppLovinSdk.getInstance( this ), this );


        atas = findViewById(R.id.atas);
        bawah = findViewById(R.id.bawah);
        calling = findViewById(R.id.txtcall);
        imguser2 = findViewById(R.id.imguser2);
        adduser = findViewById(R.id.adduser);
        adduser.setVisibility(View.INVISIBLE);
        cancel = findViewById(R.id.layclose2);
        tolak = findViewById(R.id.layclose);
        pesan = findViewById(R.id.laypesan);
        pesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                Intent intent = new Intent(TeleVoiceCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();

            }
        });
        handler = new Handler() ;
        tolak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                Intent intent = new Intent(TeleVoiceCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                if (PENGATURAN_IKLAN.equals("1")){

                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
                    } else {
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

                    }
                } else if (PENGATURAN_IKLAN.equals("3")){
                    interstitialAdlovin.showAndRender( loadedAd );
                } else if(PENGATURAN_IKLAN.equals("2")) {
                    if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                        interstitialAdfb.loadAd();
                    } else {
                        interstitialAdfb.show();

                    }
                } else if (PENGATURAN_IKLAN.equals("4")){
                    StartAppAd.showAd(TeleVoiceCallActivity.this);
                }

            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                Intent intent = new Intent(TeleVoiceCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                if (PENGATURAN_IKLAN.equals("1")){

                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
                    } else {
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

                    }
                } else if (PENGATURAN_IKLAN.equals("3")){
                    interstitialAdlovin.showAndRender( loadedAd );
                } else if(PENGATURAN_IKLAN.equals("2")) {
                    if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                        interstitialAdfb.loadAd();
                    } else {
                        interstitialAdfb.show();

                    }
                } else if (PENGATURAN_IKLAN.equals("4")){
                    StartAppAd.showAd(TeleVoiceCallActivity.this);
                }

            }
        });

        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        mp = MediaPlayer.create(getApplicationContext(), notification);
        mp.start();
        mp.setLooping(true);
        TextView judulH = findViewById(R.id.txtname);
        judulH.setText(judul);

        gambrH = findViewById(R.id.imguser);


        Picasso.get()
                .load(gambar)
                .into(gambrH);
        Picasso.get()
                .load(gambar)
                .into(imguser2);

        terima = findViewById(R.id.layterima);
        terima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                atas.setVisibility(View.GONE);
                tolak.setVisibility(View.VISIBLE);
                bawah.setVisibility(View.VISIBLE);
                imguser2.setVisibility(View.VISIBLE);
                StartTime = SystemClock.uptimeMillis();
                handler.postDelayed(runnable, 0);
                Picasso.get()
                        .load(gambar)
                        .into(imguser2);

                String url = voice;
                     mp.stop();
                    try {

                        mp = new MediaPlayer();
                        if (url.startsWith("http")) {
                            mp.setDataSource(url);
                            mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
                        } else {
                            AssetFileDescriptor descriptor;
                            descriptor = getAssets().openFd(url);
                            mp.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
                            descriptor.close();
                            mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
                        }
                        mp.prepareAsync();
                        mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                            @Override
                            public void onPrepared(MediaPlayer mp) {
                                mp.start();
                            }
                        });

                    } catch (IllegalArgumentException | IllegalStateException | IOException e) {
                        e.printStackTrace();
                    }


            }
        });


    }

    public void onBackPressed(){
     mp.stop();
        Intent intent = new Intent(TeleVoiceCallActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        if (PENGATURAN_IKLAN.equals("1")){

            if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
                mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                        .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                        .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
            } else {
                mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                        .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                        .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

            }
        } else if (PENGATURAN_IKLAN.equals("3")){
            interstitialAdlovin.showAndRender( loadedAd );
        } else if(PENGATURAN_IKLAN.equals("2")) {
            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                interstitialAdfb.loadAd();
            } else {
                interstitialAdfb.show();

            }
        } else if (PENGATURAN_IKLAN.equals("4")){
            StartAppAd.showAd(TeleVoiceCallActivity.this);
        }
    }

    public boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null
                && activeNetwork.isConnectedOrConnecting();
    }

    public Runnable runnable = new Runnable() {

        @SuppressLint({"DefaultLocale", "SetTextI18n"})
        public void run() {

            MillisecondTime = SystemClock.uptimeMillis() - StartTime;

            UpdateTime = TimeBuff + MillisecondTime;

            Seconds = (int) (UpdateTime / 1000);

            Minutes = Seconds / 60;

            Seconds = Seconds % 60;
            hours = Minutes/60;

            MilliSeconds = (int) (UpdateTime % 1000);

            calling.setText(String.format("%02d", hours) +":"+ String.format("%02d", Minutes) + ":"
                    + String.format("%02d", Seconds));

            handler.postDelayed(this, 0);
        }

    };

}