package com.aliendroid.fakecall;


import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.CountDownTimer;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.aliendroid.fakecall.config.Pengaturan;
import com.aliendroid.fakecall.util.AudienceNetworkInitializeHelper;
import com.facebook.ads.AdSettings;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK1;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK2;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK3;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK4;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK5;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_INTER;
import static com.aliendroid.fakecall.config.Pengaturan.ON_OFF_DATA;
import static com.aliendroid.fakecall.config.Pengaturan.ON_OFF_IKLAN;
import static com.aliendroid.fakecall.config.Pengaturan.TESTMODE_FAN;
import static com.aliendroid.fakecall.config.Pengaturan.URL_DATA;
import static com.facebook.ads.AdSettings.IntegrationErrorMode.INTEGRATION_ERROR_CRASH_DEBUG_MODE;


public class SplashActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AudienceNetworkInitializeHelper.initialize(this);
        AdSettings.setTestMode(TESTMODE_FAN);
        AdSettings.setIntegrationErrorMode(INTEGRATION_ERROR_CRASH_DEBUG_MODE);
        setContentView(R.layout.splash_activity);

        if (ON_OFF_IKLAN.equals("1")){
            if (checkConnectivity()){
                loadUrlData();
            }
        }

        if (ON_OFF_DATA.equals("1")){
            if (checkConnectivity()){
                /** Creates a count down timer, which will be expired after 5000 milliseconds */
                new CountDownTimer(5000, 1000) {

                    /** This method will be invoked on finishing or expiring the timer */
                    @Override
                    public void onFinish() {
                        Intent intent = new Intent(getBaseContext(), MainActivity.class);
                        startActivity(intent);
                        finish();
                    }

                    @Override
                    public void onTick(long millisUntilFinished) {

                    }
                }.start();
            } else {
                nointernetp();
            }
        } else {
            /** Creates a count down timer, which will be expired after 5000 milliseconds */
            new CountDownTimer(5000, 1000) {

                /** This method will be invoked on finishing or expiring the timer */
                @Override
                public void onFinish() {
                    Intent intent = new Intent(getBaseContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                }

                @Override
                public void onTick(long millisUntilFinished) {

                }
            }.start();
        }

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });


    }



    private void loadUrlData() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray array = jsonObject.getJSONArray("Iklan");

                    for (int i = 0; i < array.length(); i++){

                        JSONObject c = array.getJSONObject(i);

                        Pengaturan.STATUS = c.getString("status");
                        Pengaturan.LINK = c.getString("link");

                        ADMOB_INTER = c.getString("interid");
                        Pengaturan.ADMOB_NATIV = c.getString("nativeid");

                        Pengaturan.STARAPPID = c.getString("startappid");

                        Pengaturan.PENGATURAN_IKLAN = c.getString("pengaturan_iklan");

                        Pengaturan.FAN_INTER=c.getString("fan_inter");
                        Pengaturan.FAN_BANNER_NATIVE=c.getString("fan_banner_native");
                        Pengaturan.FAN_NATIVE=c.getString("fan_native");

                        ADMOB_HPK1 = c.getString("hpk_admob1");
                        ADMOB_HPK2 = c.getString("hpk_admob2");
                        ADMOB_HPK3 = c.getString("hpk_admob3");
                        ADMOB_HPK4 = c.getString("hpk_admob4");
                        ADMOB_HPK5 = c.getString("hpk_admob5");

                    }


                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                //  Toast.makeText(getActivity(), "Error" + error.toString(), Toast.LENGTH_SHORT).show();

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(SplashActivity.this);
        requestQueue.add(stringRequest);
    }


    private boolean checkConnectivity() {
        boolean enabled = true;

        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();

        if ((info == null || !info.isConnected() || !info.isAvailable())) {
            // Toast.makeText(getApplicationContext(), "Sin conexión a Internet...", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }


    }

    private void nointernetp() {
        AlertDialog.Builder builder=new AlertDialog.Builder(SplashActivity.this);
        builder.setCancelable(true);
        builder.setIcon(R.drawable.ic_baseline_network_check_24);
        builder.setTitle("Bad Connection");
        builder.setMessage("No internet access, please activate the internet to use the app!");
        builder.setInverseBackgroundForced(true);
        builder.setPositiveButton("Close",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                finish();
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        builder.setNegativeButton("Reload",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){

                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }


}
