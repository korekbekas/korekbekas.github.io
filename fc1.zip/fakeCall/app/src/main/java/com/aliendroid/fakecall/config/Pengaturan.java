package com.aliendroid.fakecall.config;


import com.aliendroid.fakecall.BuildConfig;

public class Pengaturan {


    /*
        Untuk remots ads (iklan online) menggunakan JSON maka ON_OFF_IKLAN ="1",
        sedangkan ON_OFF_IKLAN ="0" adalah mode iklan offline yang semua data di ambil dari Pengaturan.java
         */
    public static String ON_OFF_IKLAN ="0";

    /*
     Untuk data fake menggunakan Online (URL json) maka atur ON_OFF_DATA ="1",
     sedangkan ON_OFF_IKLAN ="0" adalah mode data offline dari folder asset
      */
    public static String ON_OFF_DATA ="1";


    /*PENGATURAN_IKLAN="1" untuk Admob,
      PENGATURAN_IKLAN="3" untuk APPLOVIN,
        PENGATURAN_IKLAN="2" untuk FAN,
        PENGATURAN_IKLAN="4" untuk STARTAPP,
    */
    public static String PENGATURAN_IKLAN="1";

    /*
    json untuk Guide, More App, Iklan
     */
    public static final String URL_DATA = "http://hexa.web.id/fake_call.json";

    /*Admob ID, jika aplikasi mada mode offline maka semua data iklan akan mengambil data dari Pengaturan.java
   Data pada pengaturan.java akan digantikan apabila anda bpada mode online,
   data akan digantikan dari adsremot_online.json
     */
    public static String ADMOB_INTER = "ca-app-pub-3940256099942544/1033173712";
    public static String ADMOB_NATIV = "ca-app-pub-3940256099942544/2247696110";


    public static String ADMOB_HPK1="";
    public static String ADMOB_HPK2="";
    public static String ADMOB_HPK3="";
    public static String ADMOB_HPK4="";
    public static String ADMOB_HPK5="";

    /*Redirect App, ubah STATUS = "1" untuk melakukan redirect ke aplikasi baru, fitur ini harus tetap dalam
    kedaaan STATUS = "0"; selama aplikasi masih live
     */
    public static String STATUS = "0";
    public static String LINK = "https://play.google.com/store/apps/details?id=com.alquranterjemahanindonesia.guruandroid";

    /*
    Update App - mode online - hanya digunakan jika anda menggunakan mode online dan uplaod json ke hosting
    contoh pada Builde Gradle versioncode = 1 maka di json harus version_json = 1
    saat anda melakukan update versioncode = 2 maka di jason juga harus di ubah version_json = 2
    dengan kondisi ini, maka pengguna versioncode = 1 akan mendapatkan notifikasi

    */

    public static String FAN_INTER="YOUR_PLACEMENT_ID";
    public static String FAN_BANNER_NATIVE="YOUR_PLACEMENT_ID";
    public static String FAN_NATIVE="YOUR_PLACEMENT_ID";


    public static String STARAPPID="123456789";


    /*
    VERSI_APP = BuildConfig.VERSION_CODE; jangan di ubah tetap default
     */
    public static int VERSI_APP = BuildConfig.VERSION_CODE;

    /*
    silahkan ubah dengan link GDPR
     */
    public static String Privacy_police="file:///android_asset/privacy_policy.html";
    public static String Guide_app="file:///android_asset/guide.html";

    public static  boolean TESTMODE_FAN = true;

    public static  int counter = 0;
    public static int INTERVAL =3;
}

