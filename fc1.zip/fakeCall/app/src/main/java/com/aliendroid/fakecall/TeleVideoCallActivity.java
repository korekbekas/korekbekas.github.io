package com.aliendroid.fakecall;

import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.aliendroid.fakecall.config.Pengaturan;
import com.applovin.adview.AppLovinInterstitialAd;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinSdk;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.StartAppAd;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.aliendroid.fakecall.adapter.FakeAdapter.gambar;
import static com.aliendroid.fakecall.adapter.FakeAdapter.judul;
import static com.aliendroid.fakecall.adapter.FakeAdapter.video;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK1;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK2;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK3;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK4;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK5;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_INTER;
import static com.aliendroid.fakecall.config.Pengaturan.PENGATURAN_IKLAN;

public class TeleVideoCallActivity extends AppCompatActivity implements SurfaceHolder.Callback {
    MediaPlayer mp;
    Camera camera;
    SurfaceView surfaceView,surfaceView2 ;
    SurfaceHolder surfaceHolder;
    VideoView videoView;

    private TextView calling, nameuser;
    private ImageView  adduser;
    private CircleImageView imguser;


    private RelativeLayout cancel, terima, pesan, tolak;
    Handler handler;

    private LinearLayout atas, bawah;

    private com.google.android.gms.ads.InterstitialAd mInterstitialAd;
    private com.facebook.ads.InterstitialAd interstitialAdfb;
    private AppLovinInterstitialAdDialog interstitialAdlovin;
    private AppLovinAd loadedAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tele_video_call);
        interstitialAdfb = new com.facebook.ads.InterstitialAd(this,  Pengaturan.FAN_INTER);
        interstitialAdfb.loadAd();


        mInterstitialAd = new com.google.android.gms.ads.InterstitialAd(TeleVideoCallActivity.this);
        mInterstitialAd.setAdUnitId(ADMOB_INTER);
        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());


        AppLovinSdk.getInstance( this ).getAdService().loadNextAd( AppLovinAdSize.INTERSTITIAL, new AppLovinAdLoadListener()
        {
            @Override
            public void adReceived(AppLovinAd ad)
            {
                loadedAd = ad;
            }

            @Override
            public void failedToReceiveAd(int errorCode)
            {
                // Look at AppLovinErrorCodes.java for list of error codes.
            }
        } );
        interstitialAdlovin = AppLovinInterstitialAd.create( AppLovinSdk.getInstance( this ), this );


        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        mp = MediaPlayer.create(getApplicationContext(), notification);
        mp.start();
        mp.setLooping(true);

        atas = findViewById(R.id.atas);
        bawah = findViewById(R.id.bawah);
        videoView = findViewById(R.id.videoView);


        String uriPath = video;
        if (Pengaturan.ON_OFF_DATA.equals("1")){
            Uri uri = Uri.parse(uriPath);
            videoView.setVideoURI(uri);
            videoView.requestFocus();
        } else if (Pengaturan.ON_OFF_DATA.equals("0")){
            String fileName = "android.resource://"+  BuildConfig.APPLICATION_ID + "/raw/"+video;
            videoView.setVideoURI(Uri.parse(fileName));
            videoView.requestFocus();
        }

        surfaceView = findViewById(R.id.surfaceView);
        surfaceView2 = findViewById(R.id.surfaceView2);
        surfaceView2.setVisibility(View.GONE);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setFormat(PixelFormat.OPAQUE);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);
        handler = new Handler() ;


        calling = findViewById(R.id.txtcall);
        nameuser = findViewById(R.id.txtname);
        imguser = findViewById(R.id.imguser);
        adduser = findViewById(R.id.adduser);
        adduser.setVisibility(View.INVISIBLE);
        cancel = findViewById(R.id.layclose2);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TeleVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                if (PENGATURAN_IKLAN.equals("1")){

                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
                    } else {
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

                    }
                } else if (PENGATURAN_IKLAN.equals("3")){
                    interstitialAdlovin.showAndRender( loadedAd );
                } else if(PENGATURAN_IKLAN.equals("2")) {
                    if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                        interstitialAdfb.loadAd();
                    } else {
                        interstitialAdfb.show();

                    }
                } else if (PENGATURAN_IKLAN.equals("4")){
                    StartAppAd.showAd(TeleVideoCallActivity.this);
                }
            }
        });

        pesan = findViewById(R.id.laypesan);
        pesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TeleVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                if (PENGATURAN_IKLAN.equals("1")){

                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
                    } else {
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

                    }
                } else if (PENGATURAN_IKLAN.equals("3")){
                    interstitialAdlovin.showAndRender( loadedAd );
                } else if(PENGATURAN_IKLAN.equals("2")) {
                    if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                        interstitialAdfb.loadAd();
                    } else {
                        interstitialAdfb.show();

                    }
                } else if (PENGATURAN_IKLAN.equals("4")){
                    StartAppAd.showAd(TeleVideoCallActivity.this);
                }

            }
        });

        tolak = findViewById(R.id.layclose);
        tolak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TeleVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                if (PENGATURAN_IKLAN.equals("1")){

                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
                    } else {
                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

                    }
                } else if (PENGATURAN_IKLAN.equals("3")){
                    interstitialAdlovin.showAndRender( loadedAd );
                } else if(PENGATURAN_IKLAN.equals("2")) {
                    if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                        interstitialAdfb.loadAd();
                    } else {
                        interstitialAdfb.show();

                    }
                } else if (PENGATURAN_IKLAN.equals("4")){
                    StartAppAd.showAd(TeleVideoCallActivity.this);
                }

            }
        });

        terima = findViewById(R.id.layterima);
        terima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                mp.stop();
                calling.setVisibility(View.GONE);
                nameuser.setVisibility(View.GONE);
                imguser.setVisibility(View.GONE);
                adduser.setVisibility(View.VISIBLE);
                surfaceView.setVisibility(View.GONE);
                surfaceView2.setVisibility(View.VISIBLE);
                surfaceHolder = surfaceView2.getHolder();
                surfaceHolder.addCallback(TeleVideoCallActivity.this);
                surfaceHolder.setFormat(PixelFormat.OPAQUE);
                surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);

                videoView.start();
                atas.setVisibility(View.GONE);
                bawah.setVisibility(View.VISIBLE);
                tolak.setVisibility(View.VISIBLE);

            }
        });

        imguser = findViewById(R.id.imguser);


        Picasso.get()
                .load(gambar)
                .into(imguser);

        nameuser.setText(judul);

    }

    public void surfaceCreated(SurfaceHolder surfaceHolder ) {

        camera = Camera.open(1);
        Camera.Parameters parameters;
        parameters = camera.getParameters();
        camera.setParameters(parameters);
        camera.setDisplayOrientation(90);
        try {
            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();


        }catch (Exception e){
        }

    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        camera.stopPreview();
        camera.release();
        camera=null;

    }
    public void call2(){
        new CountDownTimer(7000, 1000) {
            @Override
            public void onFinish() {


                mp.stop();
                calling.setVisibility(View.GONE);
                nameuser.setVisibility(View.GONE);
                imguser.setVisibility(View.GONE);
                adduser.setVisibility(View.VISIBLE);
                surfaceView.setVisibility(View.GONE);
                surfaceView2.setVisibility(View.VISIBLE);
                videoView.start();
            }
            @Override
            public void onTick(long millisUntilFinished) {
                surfaceHolder = surfaceView2.getHolder();
                surfaceHolder.addCallback(TeleVideoCallActivity.this);
                surfaceHolder.setFormat(PixelFormat.OPAQUE);
                surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);

            }
        }.start();
    }
    public void onBackPressed(){
        mp.stop();
        Intent intent = new Intent(TeleVideoCallActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        if (PENGATURAN_IKLAN.equals("1")){

            if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
                mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                        .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                        .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
            } else {
                mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                        .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                        .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

            }
        } else if (PENGATURAN_IKLAN.equals("3")){
            interstitialAdlovin.showAndRender( loadedAd );
        } else if(PENGATURAN_IKLAN.equals("2")) {
            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                interstitialAdfb.loadAd();
            } else {
                interstitialAdfb.show();

            }
        } else if (PENGATURAN_IKLAN.equals("4")){
            StartAppAd.showAd(TeleVideoCallActivity.this);
        }
    }




}