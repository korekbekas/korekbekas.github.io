package com.aliendroid.fakecall.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.applovin.adview.AppLovinInterstitialAd;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinSdk;
import com.aliendroid.fakecall.DetailFakeActivity;
import com.aliendroid.fakecall.R;
import com.aliendroid.fakecall.config.Pengaturan;
import com.aliendroid.fakecall.model.Item;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.StartAppAd;

import java.util.List;

import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK1;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK2;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK3;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK4;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_HPK5;
import static com.aliendroid.fakecall.config.Pengaturan.ADMOB_INTER;
import static com.aliendroid.fakecall.config.Pengaturan.INTERVAL;
import static com.aliendroid.fakecall.config.Pengaturan.PENGATURAN_IKLAN;
import static com.aliendroid.fakecall.config.Pengaturan.counter;


public class FakeAdapter extends RecyclerView.Adapter {

    public static com.google.android.gms.ads.InterstitialAd mInterstitialAd;
    public static com.facebook.ads.InterstitialAd interstitialAdfb;
    private static AppLovinInterstitialAdDialog interstitialAdlovin;
    private static AppLovinAd loadedAd;
    public static String judul ;
    public static String gambar ;
    public static String voice;
    public static String video;
    public static List<Item> webLists;
    public Context context;

    public FakeAdapter(List<Item> webLists, Context context) {

        // generate constructors to initialise the List and Context objects

        this.webLists = webLists;
        this.context = context;

        interstitialAdfb = new com.facebook.ads.InterstitialAd(context,  Pengaturan.FAN_INTER);
        interstitialAdfb.loadAd();

        mInterstitialAd = new com.google.android.gms.ads.InterstitialAd(context);
        mInterstitialAd.setAdUnitId(ADMOB_INTER);
        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());


        AppLovinSdk.getInstance( context).getAdService().loadNextAd( AppLovinAdSize.INTERSTITIAL, new AppLovinAdLoadListener()
        {
            @Override
            public void adReceived(AppLovinAd ad)
            {
                loadedAd = ad;
            }

            @Override
            public void failedToReceiveAd(int errorCode)
            {
                // Look at AppLovinErrorCodes.java for list of error codes.
            }
        } );
        interstitialAdlovin = AppLovinInterstitialAd.create( AppLovinSdk.getInstance( context ), context );

    }

    public class ViewHolder extends RecyclerView.ViewHolder  {


        public ImageView avatar_url;
        public RelativeLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);

            avatar_url = (ImageView) itemView.findViewById(R.id.img_fake);
            linearLayout = itemView.findViewById(R.id.klik_fake);

        }




    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


                View v = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.fake_list, parent, false);
                return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {

          if (holder instanceof ViewHolder) {
                    final Item webList = webLists.get(position);


                    Picasso.get()
                            .load(webList.getImage_url())
                            .into( ((ViewHolder)holder).avatar_url);

                    ((ViewHolder)holder).linearLayout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            judul = webList.getNamefake();
                            gambar = webList.getImage_url();
                            voice = webList.getVoice_url();
                            video = webList.getViode_url();
                            Intent intent = new Intent(context, DetailFakeActivity.class);
                            context.startActivity(intent);


                            if (counter>=INTERVAL){
                                if (PENGATURAN_IKLAN.equals("1")){

                                    if (mInterstitialAd.isLoaded()) {
                                        mInterstitialAd.show();
                                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());
                                    } else {
                                        mInterstitialAd.loadAd(new AdRequest.Builder().addKeyword(ADMOB_HPK1)
                                                .addKeyword(ADMOB_HPK2).addKeyword(ADMOB_HPK3)
                                                .addKeyword(ADMOB_HPK4).addKeyword(ADMOB_HPK5).build());

                                    }
                                } else if (PENGATURAN_IKLAN.equals("3")){
                                    interstitialAdlovin.showAndRender( loadedAd );
                                } else if(PENGATURAN_IKLAN.equals("2")) {
                                    if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                                        interstitialAdfb.loadAd();
                                    } else {
                                        interstitialAdfb.show();

                                    }
                                } else if (PENGATURAN_IKLAN.equals("4")){
                                    StartAppAd.showAd(context);
                                }
                                counter=0;
                            } else {
                                counter++;
                            }



                        }
                    });

        }

    }

    public int getItemCount() {
        return webLists.size();
    }

}
