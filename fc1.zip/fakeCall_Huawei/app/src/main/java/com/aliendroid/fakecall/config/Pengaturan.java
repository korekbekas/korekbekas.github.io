package com.aliendroid.fakecall.config;


public class Pengaturan {


    /*
     Untuk data fake menggunakan Online (URL json) maka atur ON_OFF_DATA ="1",
     sedangkan ON_OFF_IKLAN ="0" adalah mode data offline dari folder asset
      */
    public static String ON_OFF_DATA ="1";

    /*
    json untuk Guide, More App, Iklan
     */
    public static final String URL_DATA = "http://hexa.web.id/fake_call.json";

    public static String STATUS = "0";
    public static String LINK = "https://play.google.com/store/apps/details?id=c";

    /*
    silahkan ubah dengan link GDPR
     */
    public static String Privacy_police="file:///android_asset/privacy_policy.html";
    public static String Guide_app="file:///android_asset/guide.html";



}

