package com.aliendroid.fakecall.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.aliendroid.fakecall.DetailFakeActivity;
import com.aliendroid.fakecall.R;
import com.aliendroid.fakecall.config.Pengaturan;
import com.aliendroid.fakecall.model.Item;
import com.huawei.hms.ads.AdParam;
import com.huawei.hms.ads.InterstitialAd;
import com.squareup.picasso.Picasso;

import java.util.List;


public class FakeAdapter extends RecyclerView.Adapter {


    public static String judul ;
    public static String gambar ;
    public static String voice;
    public static String video;
    public static List<Item> webLists;
    public Context context;
    private InterstitialAd interstitialAd;
    public FakeAdapter(List<Item> webLists, Context context) {

        // generate constructors to initialise the List and Context objects

        this.webLists = webLists;
        this.context = context;
        interstitialAd = new InterstitialAd(context);
        interstitialAd.setAdId(context.getString(R.string.image_ad_id));
        AdParam adParam = new AdParam.Builder().build();
        interstitialAd.loadAd(adParam);

    }

    public class ViewHolder extends RecyclerView.ViewHolder  {


        public ImageView avatar_url;
        public RelativeLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);

            avatar_url = (ImageView) itemView.findViewById(R.id.img_fake);
            linearLayout = itemView.findViewById(R.id.klik_fake);

        }




    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


                View v = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.fake_list, parent, false);
                return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {

          if (holder instanceof ViewHolder) {
                    final Item webList = webLists.get(position);


                    Picasso.get()
                            .load(webList.getImage_url())
                            .into( ((ViewHolder)holder).avatar_url);

                    ((ViewHolder)holder).linearLayout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            judul = webList.getNamefake();
                            gambar = webList.getImage_url();
                            voice = webList.getVoice_url();
                            video = webList.getViode_url();
                            Intent intent = new Intent(context, DetailFakeActivity.class);
                            context.startActivity(intent);

                                if (interstitialAd != null && interstitialAd.isLoaded()) {
                                    interstitialAd.show();
                                } else {
                                    Toast.makeText(context, "Ad did not load", Toast.LENGTH_SHORT).show();
                                }

                        }
                    });

        }

    }

    public int getItemCount() {
        return webLists.size();
    }

}
