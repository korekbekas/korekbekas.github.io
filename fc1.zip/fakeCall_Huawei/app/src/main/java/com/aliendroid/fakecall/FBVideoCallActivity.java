package com.aliendroid.fakecall;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import com.aliendroid.fakecall.config.Pengaturan;
import com.huawei.hms.ads.AdParam;
import com.huawei.hms.ads.InterstitialAd;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.aliendroid.fakecall.adapter.FakeAdapter.gambar;
import static com.aliendroid.fakecall.adapter.FakeAdapter.judul;
import static com.aliendroid.fakecall.adapter.FakeAdapter.video;

public class FBVideoCallActivity extends AppCompatActivity implements SurfaceHolder.Callback{
    CircleImageView gambrH;
    ImageView gambrB, imgback;
    MediaPlayer mp;
    RelativeLayout terima, tolak, tolak2, atas2;
    LinearLayout atas, bawah;
    int Seconds, Minutes, MilliSeconds, hours ;
    long MillisecondTime, StartTime, TimeBuff, UpdateTime = 0L ;
    Handler handler;
    TextView calling;
    Camera camera;
    SurfaceView surfaceView ;
    SurfaceHolder surfaceHolder;
    VideoView videoView;

    private InterstitialAd interstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_f_b_video_call);
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdId(getString(R.string.image_ad_id));
        AdParam adParam = new AdParam.Builder().build();
        interstitialAd.loadAd(adParam);

        surfaceView = findViewById(R.id.surfaceView);
        surfaceView.setVisibility(View.GONE);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setFormat(PixelFormat.OPAQUE);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);
        videoView = findViewById(R.id.videoView);
        videoView.setMediaController(null);

        String uriPath = video;
        if (Pengaturan.ON_OFF_DATA.equals("1")){
            Uri uri = Uri.parse(uriPath);
            videoView.setVideoURI(uri);
            videoView.requestFocus();
        } else if (Pengaturan.ON_OFF_DATA.equals("0")){
            String fileName = "android.resource://"+  BuildConfig.APPLICATION_ID + "/raw/"+video;
            videoView.setVideoURI(Uri.parse(fileName));
            videoView.requestFocus();
        }

        handler = new Handler() ;
        atas = findViewById(R.id.layutama);
        bawah = findViewById(R.id.laybawah2);
        calling = findViewById(R.id.txtwaktu);

        mp = MediaPlayer.create(this, R.raw.facebook);
        mp.start();
        mp.setLooping(true);

        tolak = findViewById(R.id.laytolak);
        tolak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FBVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    interstitialAd.show();
                } else {
                    Toast.makeText(FBVideoCallActivity.this, "Ad did not load", Toast.LENGTH_SHORT).show();
                }

            }
        });

        imgback = findViewById(R.id.imgback2);
        imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FBVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    interstitialAd.show();
                } else {
                    Toast.makeText(FBVideoCallActivity.this, "Ad did not load", Toast.LENGTH_SHORT).show();
                }
            }
        });

        tolak2 = findViewById(R.id.laytolak2);
        tolak2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FBVideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    interstitialAd.show();
                } else {
                    Toast.makeText(FBVideoCallActivity.this, "Ad did not load", Toast.LENGTH_SHORT).show();
                }
            }
        });

        terima = findViewById(R.id.layterima);
        terima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                surfaceView.setVisibility(View.VISIBLE);
                atas.setVisibility(View.GONE);
                bawah.setVisibility(View.VISIBLE);
                gambrB.setVisibility(View.GONE);
                videoView.start();


            }
        });


        TextView judulH = findViewById(R.id.txtfbname);
        judulH.setText(judul);

        gambrH = findViewById(R.id.fbimguser);
        gambrB = findViewById(R.id.imgback);

        Picasso.get()
                .load(gambar)
                .into(gambrH);
        Picasso.get()
                .load(gambar)
                .into(gambrB);
    }


    public Runnable runnable = new Runnable() {

        @SuppressLint({"DefaultLocale", "SetTextI18n"})
        public void run() {

            MillisecondTime = SystemClock.uptimeMillis() - StartTime;

            UpdateTime = TimeBuff + MillisecondTime;

            Seconds = (int) (UpdateTime / 1000);

            Minutes = Seconds / 60;

            Seconds = Seconds % 60;
            hours = Minutes/60;

            MilliSeconds = (int) (UpdateTime % 1000);

            calling.setText(String.format("%02d", hours) +":"+ String.format("%02d", Minutes) + ":"
                    + String.format("%02d", Seconds));

            handler.postDelayed(this, 0);
        }

    };

    public void onBackPressed(){
        mp.stop();
        Intent intent = new Intent(FBVideoCallActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        if (interstitialAd != null && interstitialAd.isLoaded()) {
            interstitialAd.show();
        } else {
            Toast.makeText(FBVideoCallActivity.this, "Ad did not load", Toast.LENGTH_SHORT).show();
        }
    }

    public void surfaceCreated(SurfaceHolder surfaceHolder ) {

        camera = Camera.open(1);
        Camera.Parameters parameters;
        parameters = camera.getParameters();
        camera.setParameters(parameters);
        camera.setDisplayOrientation(90);
        try {
            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();


        }catch (Exception e){
        }

    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        camera.stopPreview();
        camera.release();
        camera=null;

    }

}