package com.aliendroid.fakecall;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aliendroid.fakecall.config.Pengaturan;
import com.aliendroid.fakecall.util.AppReceiver;
import com.huawei.hms.ads.AdParam;
import com.huawei.hms.ads.banner.BannerView;
import com.squareup.picasso.Picasso;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.aliendroid.fakecall.adapter.FakeAdapter.gambar;
import static com.aliendroid.fakecall.adapter.FakeAdapter.judul;


public class DetailFakeActivity extends AppCompatActivity  {
    private BannerView defaultBannerView;
    private static final int REFRESH_TIME = 30;
    private int NOTIFICATION_ID = 1;
    private PendingIntent pendingIntent;
    private static final int ALARM_REQUEST_CODE = 134;
    private RadioGroup list_action, list_form, list_time;
    protected static final String TAG = DetailFakeActivity.class.getSimpleName();
    public static int rd_vid =1;
    public static int rd_form =1;
    public static int rd_time =1;
    public static String status_time="Wait for 2 seconds";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detai_fake_activity);
        defaultBannerView = findViewById(R.id.hw_banner_view);
        defaultBannerView.setBannerRefresh(REFRESH_TIME);
        AdParam adParam = new AdParam.Builder().build();
        defaultBannerView.loadAd(adParam);

        TextView judulH = findViewById(R.id.txtjudul);


        list_action = findViewById(R.id.list_action);
        list_action.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id){
                    case R.id.rd_vid:
                        rd_vid = 1;

                        break;
                    case R.id.rd_voic:
                        rd_vid = 2;
                        break;

                }
            }
        });


        list_form = findViewById(R.id.lict_form);
        list_form.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id){
                    case R.id.rdwa:
                        rd_form = 1;
                        break;
                    case R.id.rdfb:
                        rd_form = 2;
                        break;
                    case R.id.rdduo:
                        rd_form = 3;
                        break;

                }
            }
        });

        list_time = findViewById(R.id.list_time);
        list_time.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id){
                    case R.id.rd1:
                        rd_time = 1;
                        status_time = "Wait for 2 seconds";
                        break;
                    case R.id.rd10:
                        rd_time = 10;
                        status_time = "Wait for 10 seconds";
                        break;
                    case R.id.rd30:
                        rd_time = 30;
                        status_time = "Wait for 30 seconds";
                        break;
                    case R.id.rd60:
                        rd_time = 60;
                        status_time = "Wait for 1 minutes";
                        break;
                    case R.id.rd300:
                        rd_time = 300;
                        status_time = "Wait for 5 minutes";
                        break;

                }
            }
        });

        judulH.setText(judul);

        CircleImageView gambrH = findViewById(R.id.imageheader);

        Picasso.get()
                .load(gambar)
                .into(gambrH);

        Intent alarmIntent = new Intent(this, AppReceiver.class);
        pendingIntent = PendingIntent.getBroadcast(this, ALARM_REQUEST_CODE, alarmIntent, 0);

        Button tbtutor = findViewById(R.id.tblstart);
        tbtutor.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                if (rd_time==1) {
                    if (rd_form == 1) {
                        if (rd_vid == 2) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, WAVoiceCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else if (rd_vid == 1) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, WAVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else {
                            Intent intent2 = new Intent(DetailFakeActivity.this, WAVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        }
                    } else if (rd_form == 2) {
                        if (rd_vid == 2) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, FBVoiceCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else if (rd_vid == 1) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, FBVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else {
                            Intent intent2 = new Intent(DetailFakeActivity.this, FBVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        }
                    }else if (rd_form == 3) {
                        if (rd_vid == 2) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, TeleVoiceCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else if (rd_vid == 1) {
                            Intent intent2 = new Intent(DetailFakeActivity.this, TeleVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        } else {
                            Intent intent2 = new Intent(DetailFakeActivity.this, TeleVideoCallActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent2);
                        }
                    }
                } else {
                    Calendar cal = Calendar.getInstance();
                    cal.add(Calendar.SECOND, rd_time);
                    AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    //set alarm manager dengan memasukkan waktu yang telah dikonversi menjadi milliseconds
                    manager.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
                    Toast.makeText(DetailFakeActivity.this, status_time, Toast.LENGTH_SHORT).show();
                    finish();
                    MainActivity.fa.finish();

                }
                /*
                Intent intent = new Intent(DetaiFakeActivity.this, TeleVideoCallActivity.class);
                startActivity(intent);

                //set waktu sekarang berdasarkan interval
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.SECOND, rd_time);
                AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                //set alarm manager dengan memasukkan waktu yang telah dikonversi menjadi milliseconds
                manager.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
                Toast.makeText(DetaiFakeActivity.this, status_time, Toast.LENGTH_SHORT).show();
                finish();
                MainActivity.fa.finish();

                 */

            }
        });
    }


    @Override
    public void onBackPressed()
    {
       finish();
    }

}