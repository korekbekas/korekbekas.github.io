package com.aliendroid.fakecall;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.aliendroid.fakecall.config.AdsConstant;
import com.aliendroid.fakecall.dialogs.ConsentDialog;
import com.aliendroid.fakecall.dialogs.ProtocolDialog;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.aliendroid.fakecall.config.Pengaturan;
import com.aliendroid.fakecall.util.AppReceiver;
import com.aliendroid.fakecall.adapter.FakeAdapter;
import com.aliendroid.fakecall.adapter.MoreAdapter;
import com.aliendroid.fakecall.model.Item;
import com.aliendroid.fakecall.model.MoreList;
import com.google.android.material.snackbar.Snackbar;
import com.huawei.hms.ads.AdParam;
import com.huawei.hms.ads.banner.BannerView;
import com.huawei.hms.ads.consent.bean.AdProvider;
import com.huawei.hms.ads.consent.constant.ConsentStatus;
import com.huawei.hms.ads.consent.constant.DebugNeedConsent;
import com.huawei.hms.ads.consent.inter.Consent;
import com.huawei.hms.ads.consent.inter.ConsentUpdateListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static com.aliendroid.fakecall.config.Pengaturan.LINK;
import static com.aliendroid.fakecall.config.Pengaturan.ON_OFF_DATA;
import static com.aliendroid.fakecall.config.Pengaturan.STATUS;
import static com.aliendroid.fakecall.config.Pengaturan.URL_DATA;


public class MainActivity extends AppCompatActivity {
    private BannerView defaultBannerView;
    private static final int REFRESH_TIME = 30;

    private PendingIntent pendingIntent;
    private static final int ALARM_REQUEST_CODE = 134;
    //set interval notifikasi 10 detik
    private int interval_seconds = 10;
    private int NOTIFICATION_ID = 1;

    private RecyclerView recyclerView;
    private MoreAdapter adapter;
    List<MoreList> webLists;
    private static final int MY_REQUEST_CODE = 17326;

    public static Activity fa;
    private RecyclerView recFake;
    private FakeAdapter adapterFake;
    List<Item> fakeLists;
    private LinearLayout laymore;
    private static final String TAG = MainActivity.class.getSimpleName();
    /*
   GDPR
    */
    private static final int PROTOCOL_MSG_TYPE = 100;

    private static final int CONSENT_MSG_TYPE = 200;

    private static final int MSG_DELAY_MS = 1000;

    private Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            if (MainActivity.this.hasWindowFocus()) {
                switch (msg.what) {
                    case PROTOCOL_MSG_TYPE:
                        showPrivacyDialog();
                        break;
                    case CONSENT_MSG_TYPE:
                        checkConsentStatus();
                        break;
                }
            }
            return false;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sendMessage(PROTOCOL_MSG_TYPE, MSG_DELAY_MS);
        Button howto = findViewById(R.id.tbhow);

        defaultBannerView = findViewById(R.id.hw_banner_view);
        defaultBannerView.setBannerRefresh(REFRESH_TIME);
        AdParam adParam = new AdParam.Builder().build();
        defaultBannerView.loadAd(adParam);

        howto.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, GuideActivity.class);
                startActivity(intent);

            }
        });

        Button privacy = findViewById(R.id.tbpri);
        privacy.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, PrivacyActivity.class);
                startActivity(intent);

            }
        });

        if (STATUS.equals("1")) {

            String str = LINK;
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(str)));
            finish();
        }

        {
            fa = this;
        }
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[] {Manifest.permission.CAMERA}, 1);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (!Settings.canDrawOverlays(this)) {
                checkPermission();

            }
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            int LAYOUT_FLAG = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams mWindowParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    LAYOUT_FLAG, // Overlay over the other apps.
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE    // This flag will enable the back key press.
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, // make the window to deliver the focus to the BG window.
                    PixelFormat.TRANSPARENT);
        }

        recyclerView = (RecyclerView)findViewById(R.id.recmore);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager HorizontalLayout = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,
                false);
        recyclerView.setLayoutManager(HorizontalLayout);

        webLists = new ArrayList<>();

        laymore = findViewById(R.id.laymore);

        final Button tbmore = findViewById(R.id.tbmore);
        tbmore.setBackground(getResources().getDrawable(R.drawable.ic_baseline_keyboard_arrow_down_24));
        tbmore.setTag("gray");
        tbmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String tag = tbmore.getTag().toString();
                if(tag.equalsIgnoreCase("gray"))
                {

                    tbmore.setTag("red");
                    tbmore.setBackground(getResources().getDrawable(R.drawable.ic_baseline_keyboard_arrow_up_24));
                    laymore.setVisibility(View.VISIBLE);
                }
                else
                {

                    tbmore.setTag("gray");
                    tbmore.setBackground(getResources().getDrawable(R.drawable.ic_baseline_keyboard_arrow_down_24));
                    laymore.setVisibility(View.GONE);
                }

            }
        });


        recFake = (RecyclerView) findViewById(R.id.recfake);
        recFake.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 3);
        recFake.setLayoutManager(mLayoutManager);
        fakeLists = new ArrayList<>();


        if (ON_OFF_DATA.equals("1")){
            if (checkConnectivity()){
                loadUrlDataFake();
                loadUrlDataMore();
            }
        } else {
            datamore();
            dataFake();
        }


        Intent alarmIntent = new Intent(MainActivity.this, AppReceiver.class);
        pendingIntent = PendingIntent.getBroadcast(MainActivity.this, ALARM_REQUEST_CODE, alarmIntent, 0);
    }

    public void startAlarmManager(View v) {
        //set waktu sekarang berdasarkan interval
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.SECOND, interval_seconds);
        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        //set alarm manager dengan memasukkan waktu yang telah dikonversi menjadi milliseconds
        manager.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
        Toast.makeText(this, "AlarmManager Start.", Toast.LENGTH_SHORT).show();
        finish();
    }

    //Stop/Cancel alarm manager
    public void stopAlarmManager(View v) {
        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        manager.cancel(pendingIntent);
        //close existing/current notifications
        NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(NOTIFICATION_ID);
        //jika app ini mempunyai banyak notifikasi bisa di cancelAll()
        //notificationManager.cancelAll();
        Toast.makeText(this, "AlarmManager Stopped by User.", Toast.LENGTH_SHORT).show();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_share) {
            String shareLink = "https://appgallery.huawei.com/#/app/"
                    + getString(R.string.IDHuawei);
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT,
                    getResources().getString(R.string.shareit)+" "
                            + shareLink);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
            return true;
        } else if (id == R.id.menu_rate) {
            String str = "https://appgallery.huawei.com/#/app/"
                    + getString(R.string.IDHuawei);
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(str)));
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }



    public String loadJSONFromAsset() {
        String json = null;
        try {

            InputStream is = getAssets().open("fake_call.json");

            int size = is.available();

            byte[] buffer = new byte[size];

            is.read(buffer);

            is.close();

            json = new String(buffer, "UTF-8");


        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    public void datamore(){
        try {
            JSONObject jsonObject = new JSONObject(loadJSONFromAsset());
            JSONArray jsonArray = jsonObject.getJSONArray("More");
            // Extract data from json and store into ArrayList as class objects
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonData = jsonArray.getJSONObject(i);
                MoreList dataUrl = new MoreList();
                dataUrl.id = jsonData.getInt("id");
                dataUrl.name = jsonData.getString("judul");
                dataUrl.image_url = jsonData.getString("image");
                dataUrl.link_url = jsonData.getString("link");
                webLists.add(dataUrl);

            }

            adapter = new MoreAdapter(webLists, MainActivity.this);
            recyclerView.setAdapter(adapter);

        } catch (JSONException e) {
            Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }


    public void dataFake(){
        try {
            JSONObject jsonObject = new JSONObject(loadJSONFromAsset());
            JSONArray jsonArray = jsonObject.getJSONArray("Item");
            // Extract data from json and store into ArrayList as class objects
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonData = jsonArray.getJSONObject(i);
                Item dataUrl = new Item();
                dataUrl.Id = jsonData.getInt("id");
                dataUrl.namefake = jsonData.getString("name");
                dataUrl.image_url = jsonData.getString("image_url");
                dataUrl.viode_url = jsonData.getString("video_url");
                dataUrl.voice_url = jsonData.getString("voice_url");
                fakeLists.add(dataUrl);

            }

            adapterFake = new FakeAdapter(fakeLists, MainActivity.this);
            recFake.setAdapter(adapterFake);

        } catch (JSONException e) {
            Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }


    private boolean checkConnectivity() {
        boolean enabled = true;

        ConnectivityManager connectivityManager = (ConnectivityManager) MainActivity.this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();

        if ((info == null || !info.isConnected() || !info.isAvailable())) {
            // Toast.makeText(getApplicationContext(), "Sin conexión a Internet...", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }


    }

    private void exitapp() {
        AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
        builder.setCancelable(true);
        builder.setIcon(R.drawable.ic_baseline_cancel_24);
        builder.setTitle("Exit App");
        builder.setMessage("Are you sure you want to leave the application?");
        builder.setInverseBackgroundForced(true);
        builder.setPositiveButton("Yes",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                finish();

            }
        });

        builder.setNegativeButton("No",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which){
                dialog.dismiss();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }

    @Override
    public void onBackPressed()
    {
        exitapp();
    }

    private void loadUrlDataFake() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray array = jsonObject.getJSONArray("Item");

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonData = array.getJSONObject(i);
                        Item dataUrl = new Item();
                        dataUrl.Id = jsonData.getInt("id");
                        dataUrl.namefake = jsonData.getString("name");
                        dataUrl.image_url = jsonData.getString("image_url");
                        dataUrl.viode_url = jsonData.getString("video_url");
                        dataUrl.voice_url = jsonData.getString("voice_url");
                        fakeLists.add(dataUrl);

                    }

                    adapterFake = new FakeAdapter(fakeLists, MainActivity.this);
                    recFake.setAdapter(adapterFake);

                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                //  Toast.makeText(getActivity(), "Error" + error.toString(), Toast.LENGTH_SHORT).show();

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(stringRequest);
    }


    private void loadUrlDataMore() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray array = jsonObject.getJSONArray("More");

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonData = array.getJSONObject(i);
                        MoreList dataUrl = new MoreList();
                        dataUrl.id = jsonData.getInt("id");
                        dataUrl.name = jsonData.getString("judul");
                        dataUrl.image_url = jsonData.getString("image");
                        dataUrl.link_url = jsonData.getString("link");
                        webLists.add(dataUrl);

                    }

                    adapter = new MoreAdapter(webLists, MainActivity.this);
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                //  Toast.makeText(getActivity(), "Error" + error.toString(), Toast.LENGTH_SHORT).show();

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(stringRequest);
    }
    public static int ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE = 5469;
    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE) {
            if (!Settings.canDrawOverlays(this)) {
                // You don't have permission
                checkPermission();
            } else {
                // Do as per your logic
            }

        }

    }

    public void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE);
            }
        }
    }

    private void showPrivacyDialog() {
        if (getPreferences(AdsConstant.SP_PROTOCOL_KEY, AdsConstant.DEFAULT_SP_PROTOCOL_VALUE) == 0) {
            Log.i(TAG, "Show protocol dialog.");
            ProtocolDialog dialog = new ProtocolDialog(this);
            dialog.setCallback(new ProtocolDialog.ProtocolDialogCallback() {
                @Override
                public void agree() {
                    sendMessage(CONSENT_MSG_TYPE, MSG_DELAY_MS);
                }

                @Override
                public void cancel() {
                    finish();
                }
            });
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
        } else {
            sendMessage(CONSENT_MSG_TYPE, MSG_DELAY_MS);
        }
    }

    private void showConsentDialog(List<AdProvider> adProviders) {
        Log.i(TAG, "Show consent dialog.");
        ConsentDialog dialog = new ConsentDialog(this, adProviders);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private int getPreferences(String key, int defValue) {
        SharedPreferences preferences = getSharedPreferences(AdsConstant.SP_NAME, Context.MODE_PRIVATE);
        int value = preferences.getInt(key, defValue);
        Log.i(TAG, "Key:" + key + ", Preference value is: " + value);
        return value;
    }

    private void sendMessage(int what, int delayMillis) {
        Message msg = Message.obtain();
        msg.what = what;
        mHandler.sendMessageDelayed(msg, delayMillis);
    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    private void checkConsentStatus() {
        final List<AdProvider> adProviderList = new ArrayList<>();
        Consent consentInfo = Consent.getInstance(this);
        consentInfo.addTestDeviceId("********");
        consentInfo.setDebugNeedConsent(DebugNeedConsent.DEBUG_NEED_CONSENT);
        consentInfo.requestConsentUpdate(new ConsentUpdateListener() {
            @Override
            public void onSuccess(ConsentStatus consentStatus, boolean isNeedConsent, List<AdProvider> adProviders) {
                Log.i(TAG, "ConsentStatus: " + consentStatus + ", isNeedConsent: " + isNeedConsent);
                if (isNeedConsent) {
                    if (adProviders != null && adProviders.size() > 0) {
                        adProviderList.addAll(adProviders);
                    }
                    showConsentDialog(adProviderList);
                }
            }

            @Override
            public void onFail(String errorDescription) {
                Log.e(TAG, "User's consent status failed to update: " + errorDescription);
                if (getPreferences(AdsConstant.SP_CONSENT_KEY, AdsConstant.DEFAULT_SP_CONSENT_VALUE) < 0) {
                    // In this example, if the request fails, the consent dialog box is still displayed. In this case, the ad publisher list is empty.
                    showConsentDialog(adProviderList);
                }
            }
        });
    }


}
